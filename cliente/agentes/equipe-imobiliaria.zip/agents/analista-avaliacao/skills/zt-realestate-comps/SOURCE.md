Fonte: https://github.com/zubair-trabzada/ai-realestate-claude (commit d435ddd), licença MIT. Copiado sem alterações.
