Fonte: https://github.com/hoangtng/real-estate-agents (commit b35e143), licença MIT. Único ajuste: cabeçalho YAML do SKILL.md (texto entre aspas).
