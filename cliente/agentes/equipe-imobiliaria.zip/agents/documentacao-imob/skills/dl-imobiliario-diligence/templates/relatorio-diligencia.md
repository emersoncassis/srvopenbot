# Template — Relatório de Due Diligence Imobiliária

**Imóvel:** {{endereço, matrícula nº, CRI}} · **Operação:** {{compra por R$ X}} · **Data:** {{...}}

## Conclusão: {{🟢 GO / 🟡 GO COM MITIGAÇÃO / 🔴 NO-GO}}
{{3 linhas para quem decide}}

## O imóvel
| Item | Situação | Evidência |
|---|---|---|
| Cadeia dominial (15 anos) | | matrícula anexa |
| Ônus/gravames | | |
| IPTU / condomínio | | certidões |
| Regularidade construtiva | | habite-se/averbação |

## Os vendedores
| Certidão | {{Vendedor 1}} | {{Vendedor 2}} |
|---|---|---|
| Cível / fiscal / trabalhista / protestos / federal | | |

## Riscos e mitigação
| # | Risco | Grau | Mitigação proposta |
|---|---|---|---|

## Condições recomendadas para a escritura
{{retenções, quitações no ato, outorgas, declarações}}

STATUS: {{AGUARDANDO DECISÃO DO CLIENTE}}
