Fonte: https://github.com/elevenlabs/skills (commit 64271c1), licença MIT. Copiado sem alterações.
