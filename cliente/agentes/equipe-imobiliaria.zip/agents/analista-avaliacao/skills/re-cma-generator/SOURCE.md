Fonte: https://github.com/hoangtng/real-estate-agents (commit b35e143), licença MIT. Copiado sem alterações.
