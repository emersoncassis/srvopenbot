Fonte: https://github.com/coreyhaines31/marketingskills (commit 1f83744), licença MIT. Copiado sem alterações.
