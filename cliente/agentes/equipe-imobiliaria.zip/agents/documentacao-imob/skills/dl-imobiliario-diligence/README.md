# 🏠 Due Diligence Imobiliária Completa

> A penhora descoberta depois da escritura não tem conserto barato. Esta skill roda a diligência completa — matrícula com cadeia dominial, certidões do imóvel E dos vendedores, risco de fraude — e entrega o relatório go/no-go, além de locação (com o prazo fatal da renovatória) e usucapião.

**No dia a dia:** *O cliente vai fechar a casa dos sonhos na sexta. Na quarta, a diligência volta: o imóvel está limpo, mas o vendedor responde a execução de R$ 900 mil em outra comarca — venda agora é fraude à execução na certa, e quem perde o imóvel é quem compra. O relatório sai vermelho com o caminho: reter o preço para quitar a dívida na escritura ou desistir. O cliente reclama do "atraso" na quarta e agradece pelos próximos trinta anos.*

## Por que usar

- 📜 **Matrícula lida de verdade** — cadeia dominial 15+ anos, ônus, indisponibilidades, divergência de área
- 🧾 **Certidões dos VENDEDORES** — fiscais, trabalhistas, cíveis, protestos, em todas as comarcas relevantes: fraude à execução se previne aqui
- 🚦 **Relatório go/no-go** — risco classificado com evidência anexada, no padrão de matriz de risco
- 🏢 **Locação sem armadilha** — Lei 8.245: garantias (só uma!), despejo, revisional e a renovatória com **prazo decadencial de 1 ano a 6 meses**
- 🌱 **Usucapião** — modalidades, extrajudicial (Provimento CNJ 65), ata notarial

## Instalação por modelo de IA

| Plataforma | Como instalar |
|---|---|
| **Claude Code** (recomendado) | `git clone https://github.com/neimaciel/imobiliario-diligence ~/.claude/skills/imobiliario-diligence` → invocar com `/imobiliario-diligence` |
| **Claude.ai / Claude Desktop** | Criar Projeto "Due Diligence Imobiliária Completa" → colar `SKILL.md` nas instruções → subir `workflows/`, `templates/` e `lib/` como conhecimento |
| **ChatGPT (GPT personalizado)** | Criar GPT → `SKILL.md` em *Instructions* → `workflows/`, `templates/`, `lib/` em *Knowledge* → ativar *Code Interpreter* para cálculos |
| **Gemini (Gem)** | Criar Gem "Due Diligence Imobiliária Completa" com `SKILL.md` nas instruções + arquivos anexados |
| **Gemini CLI** | Clonar o repo e referenciar o caminho no `GEMINI.md` do projeto |
| **Cursor / Windsurf / Codex CLI** | Clonar no repo do escritório e apontar `.cursor/rules` / `AGENTS.md` para `SKILL.md` |

> Regra de ouro: `SKILL.md` é sempre a **instrução de sistema**; `workflows/`, `templates/` e `lib/`
> são a **base de conhecimento**; `scripts/` (quando houver) só executa em plataformas com runtime.


## Comandos

```
/imobiliario-diligence diligencia        # checklist completo do imóvel + vendedores
/imobiliario-diligence compra            # promessa, escritura, arras, condições
/imobiliario-diligence locacao           # contratos, renovatória, despejo
/imobiliario-diligence usucapiao         # modalidade + via judicial/extrajudicial
```

## Aviso — ferramenta de apoio, não substituto

Esta skill instrumenta o advogado; **não** substitui julgamento profissional.
Estratégia processual, decisão de acordo e casos sensíveis são decisão humana —
artefatos que exigem essa decisão saem marcados `STATUS: AGUARDANDO DECISÃO DO ADVOGADO`.
Toda citação legal deve ser conferida na fonte antes do protocolo.

---
**Mantenedor:** [@neimaciel](https://github.com/neimaciel) · Suíte skills-advocacia · MIT
