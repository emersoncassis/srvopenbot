Fonte: https://github.com/ahacker-1/cre-agent-skills (commit a9a4e29), licença Apache-2.0. Copiado sem alterações.
