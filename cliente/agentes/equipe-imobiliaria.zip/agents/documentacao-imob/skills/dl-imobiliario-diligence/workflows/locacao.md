# Workflow — Locação (Lei 8.245/91)

## Contrato
- **UMA garantia só** (art. 37 §ú — duas = nulidade + contravenção): caução (máx. 3 aluguéis) × fiança × seguro-fiança × cessão fiduciária. Fiador: outorga conjugal + Súm. 549 STJ (bem de família do fiador é penhorável — informar o fiador!)
- Residencial 30+ meses: denúncia vazia ao fim; < 30 meses: prorrogação automática e denúncia vazia só após 5 anos (art. 46-47)
- Não residencial: liberdade maior; atenção à renovatória

## Ação renovatória (comercial) — O PRAZO FATAL
Requisitos (art. 51): contrato escrito, prazo determinado, 5 anos ininterruptos (soma de contratos), mesmo ramo por 3 anos.
**Propor entre 1 ano e 6 meses antes do término (§5º — DECADENCIAL)** → registrar no `prazo-sentinel` no dia da assinatura de toda locação comercial do escritório. Perdeu = mercê do locador.

## Despejo
Falta de pagamento: liminar em 15 dias com caução (art. 59 §1º, IX — contratos sem garantia) · purga da mora (art. 62): uma vez a cada 24 meses · denúncia vazia/infração: ritos próprios.

## Revisional
Após 3 anos do contrato/último acordo (art. 19): adequação ao mercado — laudo/pesquisa de mercado como prova.
