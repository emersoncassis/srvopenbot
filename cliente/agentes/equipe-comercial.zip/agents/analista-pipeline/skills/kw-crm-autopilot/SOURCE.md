Fonte: https://github.com/anthropics/knowledge-work-plugins (commit e91a134), licença Apache-2.0. Copiado sem alterações.
