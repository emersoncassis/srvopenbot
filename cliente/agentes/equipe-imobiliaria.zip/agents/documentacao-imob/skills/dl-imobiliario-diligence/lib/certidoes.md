# Lib — Certidões por Finalidade

| Certidão | Onde | Revela | Validade prática |
|---|---|---|---|
| Matrícula atualizada + ônus e ações | CRI | Propriedade, ônus, cadeia | 30 dias |
| IPTU / débitos municipais | Prefeitura | Propter rem | 30-90 dias |
| Declaração de quitação condominial | Síndico/administradora | Propter rem | Data da escritura |
| Distribuidor cível/família | TJ da comarca (cada domicílio recente) | Execuções, inventários | 30 dias |
| Executivos fiscais estadual/municipal | TJ/procuradorias | Dívida ativa ajuizada | 30 dias |
| Justiça Federal (cível/fiscal/criminal) | TRF da região | Execuções federais | 30 dias |
| Trabalhista (TRT + banco nacional TST) | TRT/TST | Reclamatórias/execuções | 30 dias |
| Protestos (5 anos) | Cartórios de protesto/central | Insolvência sinalizada | 30 dias |
| Falência/RJ (vendedor PJ) | Distribuidor da sede | | 30 dias |
| CND federal (RFB/PGFN) | e-CAC | Dívida ativa da União | 180 dias (própria) |
| CNIB | ONR | Indisponibilidades | Consulta na data |

Regra: comprador guarda TODAS as certidões da diligência por 10+ anos — são a prova da boa-fé (Súm. 375 STJ) se algum credor do vendedor aparecer.
