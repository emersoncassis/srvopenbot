# Workflow — Due Diligence

## Bloco 1 — O imóvel
- **Matrícula atualizada (< 30d)** com CADEIA DOMINIAL 15+ anos: como cada dono adquiriu; saltos, retificações e aquisições recentes suspeitas
- Ônus: hipoteca, alienação fiduciária, penhoras, indisponibilidades (CNIB), usufruto, servidões, cláusulas de inalienabilidade
- Área/descrição × realidade (divergência = retificação antes)
- IPTU (débitos = propter rem: acompanham o imóvel) · condomínio (idem — pedir declaração de quitação do síndico) · foro/laudêmio se enfitêutico · habite-se e regularidade da construção (área construída averbada × real)

## Bloco 2 — Os vendedores (PF)
Certidões (todas as comarcas de domicílio recente): distribuidor cível e criminal · executivos fiscais · **trabalhista (TST/TRTs)** · protestos (5 anos) · federal (Justiça Federal + dívida ativa/RFB) · estado civil REAL (casado vende com outorga conjugal — CC 1.647, salvo separação absoluta; união estável: declaração + risco residual).

## Bloco 3 — Vendedor PJ
Tudo acima + junta (quem assina) + certidão de falência/RJ + CND previdenciária/FGTS (obra própria) + risco de sucessão/fraude se a PJ está endividada.

## Classificação
| Achado | Risco |
|---|---|
| Matrícula limpa, vendedores limpos | 🟢 GO |
| Ação em curso contra vendedor sem insolvência aparente | 🟡 GO com mitigação (retenção/quitação na escritura, comprovar solvência remanescente — art. 792 §2º: bens outros suficientes) |
| Penhora/indisponibilidade na matrícula; execução relevante contra vendedor | 🔴 NO-GO até saneamento |
| Vendedor "tem procuração" de dono distante | 🟡🔴 conferir procuração no cartório emissor (golpe clássico) |

Relatório: `templates/relatorio-diligencia.md` + evidência (`event:"diligencia_emitida"`).
