# Workflow — Usucapião

## Modalidades (requisitos comuns: posse mansa, pacífica, ininterrupta, animus domini)
| Modalidade | Prazo | Extras |
|---|---|---|
| Extraordinária (CC 1.238) | 15 anos (10 c/ moradia ou obras) | Sem justo título/boa-fé |
| Ordinária (CC 1.242) | 10 anos (5 c/ aquisição onerosa registrada cancelada + moradia/investimentos) | Justo título + boa-fé |
| Especial urbana (CC 1.240 / CF 183) | 5 anos | ≤ 250 m², moradia, único imóvel |
| Especial rural (CC 1.239 / CF 191) | 5 anos | ≤ 50 ha, produtiva, moradia |
| Familiar (CC 1.240-A) | 2 anos | Ex-cônjuge abandonou o lar; ≤ 250 m² |
| Coletiva (Est. Cidade) | 5 anos | Núcleos urbanos de baixa renda |
⚠️ Não usucapem: bens públicos (CF 183 §3º/191 §ú) e áreas de uso comum de condomínio.

## Extrajudicial (CPC 1.071 + Provimento CNJ 65)
Cartório de registro de imóveis: **ata notarial** (tabelião atesta tempo/características da posse) + planta e memorial (responsável técnico com ART) assinados pelos confinantes (silêncio após notificação = concordância, na forma do provimento) + certidões + justo título/prova da origem da posse. Impugnação fundamentada → via judicial.

## Prova da posse (construir o dossiê)
Contas no nome (luz/água/IPTU pagos), benfeitorias com notas, testemunhas de vizinhança, fotos datadas, declaração dos antecessores (soma de posses — accessio possessionis, CC 1.243).
