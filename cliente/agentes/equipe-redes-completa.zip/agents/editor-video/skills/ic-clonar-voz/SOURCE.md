Fonte: https://github.com/emersoncassis/srvopenbot (commit 2682b98), licença ICTeam. Copiado sem alterações.
