Fonte: https://github.com/TheProsperityAgent/prosperity-real-estate-skills (commit b262bb9), licença MIT. Copiado sem alterações.
