# Changelog

## v1.0.0 — 2026-07-02

- Versão inicial: Due Diligence Imobiliária Completa
- SKILL.md orquestrador (dispatcher + detecção de papel)
- Workflows com SLA legal cronometrado
- Templates PT-BR com placeholders explícitos
- Evidence chain hash-chained
