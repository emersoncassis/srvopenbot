# Workflow — Compra e Venda

## Estrutura em 2 tempos
1. **Promessa** (compromisso): fecha preço/condições ENQUANTO a diligência roda — condição resolutiva: certidões limpas; registrável na matrícula (direito real — CC 1.417) p/ blindar contra venda dupla
2. **Escritura definitiva** + registro (quem não registra não é dono — CC 1.245)

## Cláusulas que importam
- **Arras** (CC 417-420): confirmatórias × penitenciais — definir EXPRESSAMENTE: quem desiste perde/devolve em dobro; arrependimento previsto = sem execução específica
- Condições suspensivas: financiamento aprovado, certidões limpas, quitação de ônus com o próprio preço (praxe segura: parte do preço direto ao credor hipotecário na escritura)
- Posse: data, estado do imóvel (vistoria anexa), débitos até a posse por conta do vendedor
- Evicção reforçada (CC 447+) e responsabilidade por vícios
- ITBI e custos: praxe do comprador, negociável

## Pagamento seguro
Sinal na promessa · saldo NA ESCRITURA (nunca 100% antes) · financiamento: interveniente quitante p/ hipoteca anterior · valores retidos p/ dívidas descobertas (escrow simples entre advogados).
