Fonte: https://github.com/alirezarezvani/claude-skills (commit 4680893), licença MIT. Copiado sem alterações.
