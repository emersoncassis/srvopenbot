Fonte: https://github.com/neimaciel/imobiliario-diligence (commit 89c0b7d), licença MIT. Copiado sem alterações.
