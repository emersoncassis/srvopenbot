Fonte: https://github.com/digitalsamba/claude-code-video-toolkit (commit 9a3e865), licença MIT. Copiado sem alterações.
