Fonte: https://github.com/emersoncassis/srvopenbot (commit b100dfb), licença ICTeam. Copiado sem alterações.
